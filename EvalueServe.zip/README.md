# React Assignment for Evalueserve

In this Assignment, we'll make a simple CRUD app that can add, update, or del
