import React, { useState } from 'react';
import TableFilter from 'react-table-filter';

import 'react-table-filter/lib/styles.css';


const UserTable = props => {
  const [tableData, setTableData] = useState("");
  const filterUpdated = (tableData, filterConfiguration) => {
    setTableData( tableData );
  }
  return (

    <table className="table">
      <thead className="thead-dark">
        <TableFilter
          rows={props.users}
          onFilterUpdate={filterUpdated}>
          <th filterkey="firstName">
            First Name
          </th>
          <th filterkey="lastName">
            Last Name
          </th>          
          <th filterkey="email">
            Email ID
          </th>
          <th>
            Edit/Delete
          </th>
        </TableFilter>
      </thead>
      <tbody>
        {tableData.length > 0 ?
          tableData.map(tableData => (
            <tr key={tableData.id}>
              <td>{tableData.firstName}</td>
              <td>{tableData.lastName}</td>
              <td>{tableData.email}</td>
              <td>
                <button
                  onClick={() => {
                    props.editRow(tableData)
                  }}
                  className="btn btn-info marginRight5 padding"
                >
                  Edit
            </button>
                <button
                  onClick={() => props.deleteUser(tableData.id)}
                  className="btn btn-danger padding"
                >
                  Delete
            </button>
              </td>
            </tr>
          )) :
          props.users.length > 0 ? (
            props.users.map(user => (
              <tr key={user.id}>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>{user.email}</td>
                <td>
                  <button
                    onClick={() => {
                      props.editRow(user)
                    }}
                    className="btn btn-info marginRight5 padding"
                  >
                    Edit
                </button>
                  <button
                    onClick={() => props.deleteUser(user.id)}
                    className="btn btn-danger padding"
                  >
                    Delete
                </button>
                </td>
              </tr>
            ))
          ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )
        }

      </tbody>
    </table>

  )
}
export default UserTable
