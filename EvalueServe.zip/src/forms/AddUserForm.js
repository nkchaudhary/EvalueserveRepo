import React, { useState } from 'react'

const AddUserForm = props => {
	const initialFormState = { id: null, firstName: '', lastName: '', email: '' }
	const [user, setUser] = useState(initialFormState);

	const handleInputChange = event => {
		const { name, value } = event.target

		setUser({ ...user, [name]: value })
	}

	return (

		<form
			onSubmit={event => {
				event.preventDefault()
				if (!user.firstName || !user.lastName || !user.email) return

				props.addUser(user)
				setUser(initialFormState)
			}}
		>
			{/* <label>First Name</label> */}
			<input type="text" name="firstName" placeholder="First Name" required value={user.firstName} onChange={handleInputChange} />
			{/* <label>Last Name</label> */}
			<input type="text" name="lastName" placeholder="Last Name" required value={user.lastName} onChange={handleInputChange} />
			{/* <label>Email Id</label> */}
			<input type="text" name="email" placeholder="Email Id" required value={user.email} onChange={handleInputChange} />
			<button className="btn btn-primary">Add new user</button>
		</form>
	)
}

export default AddUserForm
