import React, { useState, Fragment } from 'react'
import AddUserForm from './forms/AddUserForm'
import EditUserForm from './forms/EditUserForm'
import UserTable from './tables/UserTable';
import Ticktok from './ticktok/ticktok';


const App = () => {
	// Data
	const randomUser = [
		{ id: 1, firstName: 'Narendra', lastName: "kumar", email: 'nkc@gmail.com' },
		{ id: 2, firstName: 'Kumar', lastName: "kumar", email: 'kumar@gmail.com' },
		{ id: 3, firstName: 'Evalueserve', lastName: "kumar", email: 'Eval@gmail.com' },
	]

	const initialFormState = { id: null, firstName: '', lastName: '', email: '' }

	// Setting state
	const [users, setUsers] = useState(randomUser)
	const [currentUser, setCurrentUser] = useState(initialFormState)
	const [editing, setEditing] = useState(false)

	// CRUD operations
	const addUser = user => {
		user.id = users.length + 1
		setUsers([...users, user])
	}

	const deleteUser = id => {
		setEditing(false)

		setUsers(users.filter(user => user.id !== id))
	}

	const updateUser = (id, updatedUser) => {
		setEditing(false)

		setUsers(users.map(user => (user.id === id ? updatedUser : user)))
	}

	const editRow = user => {
		setEditing(true)
		setCurrentUser({ id: user.id, firstName: user.firstName, lastName: user.lastName, email: user.email })
	}

	return (
		<div className="container-fluid">
			<div className="12">
				<div className="row">
					<div className="col-lg-4"><Ticktok /></div>
					<div className="col-lg-8 box">
						<h1 className="title">Evalueserve- Assignment</h1>
						<div className="flex-row">
							<div className="">
								{editing ? (
									<Fragment>
										<h2>Edit user</h2>
										<EditUserForm
											editing={editing}
											setEditing={setEditing}
											currentUser={currentUser}
											updateUser={updateUser}
										/>
									</Fragment>
								) : (
										<Fragment>
											<h2>Add user</h2>
											<AddUserForm addUser={addUser} />
										</Fragment>
									)}
							</div>
							<div className="flex-large">
								<h2>View users</h2>
								<UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default App
