import React, { useState, useEffect } from 'react'

const EditUserForm = props => {
  const [ user, setUser ] = useState(props.currentUser)

  useEffect(
    () => {
      setUser(props.currentUser)
    },
    [ props ]
  )
  // You can tell React to skip applying an effect if certain values haven’t changed between re-renders. [ props ]

  const handleInputChange = event => {
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
  }

  return (
    <form
      onSubmit={event => {
        event.preventDefault()

        props.updateUser(user.id, user)
      }}
    >
      {/* <label>First Name</label> */}
      <input type="text" name="firstName" value={user.firstName} onChange={handleInputChange} />
      {/* <label>Last Name</label> */}
      <input type="text" name="lastName" value={user.lastName} onChange={handleInputChange} />      
      {/* <label>Email Id</label> */}
      <input type="text" name="email" value={user.email} onChange={handleInputChange} />
      <button className="btn btn-primary marginRight5">Update user</button>
      <button onClick={() => props.setEditing(false)} className="btn btn-info">
        Cancel
      </button>
    </form>
  )
}

export default EditUserForm
